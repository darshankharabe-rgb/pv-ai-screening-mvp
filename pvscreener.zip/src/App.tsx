import { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Upload, 
  Share2, 
  Activity, 
  ShieldCheck, 
  Tags, 
  Users,
  Search,
  ArrowRight,
  ClipboardList,
  ChevronRight,
  Database,
  FileText
} from 'lucide-react';
import Sidebar from './components/Sidebar';
import Header from './components/Header';

// Mock ICSR Data
const MOCK_RESULTS = [
  { id: '1', event: 'Gastrointestinal Bleeding', drug: 'Ibuprofen', patient: 'Male, 65', severity: 'High', date: '2024-05-18' },
  { id: '2', event: 'Urticaria', drug: 'Amoxicillin', patient: 'Female, 24', severity: 'Medium', date: '2024-05-17' },
  { id: '3', event: 'Dizziness', drug: 'Lisinopril', patient: 'Male, 72', severity: 'Low', date: '2024-05-16' },
];

export default function App() {
  const [activePage, setActivePage] = useState('dashboard');
  const [currentTab, setCurrentTab] = useState('search');
  const [inputText, setInputText] = useState('');
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [showResults, setShowResults] = useState(false);

  const handleAnalyze = () => {
    if (!inputText.trim()) return;
    setIsAnalyzing(true);
    // Simulate API delay
    setTimeout(() => {
      setIsAnalyzing(false);
      setShowResults(true);
    }, 1500);
  };

  const LandingScreen = () => (
    <motion.main 
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -10 }}
      className="flex-1 flex flex-col items-center justify-center p-10 relative"
    >
      <div className="absolute inset-0 pointer-events-none clinical-grid opacity-30" />
      
      <div className="w-full max-w-3xl relative z-10">
        <div className="text-center mb-10">
          <h2 className="headline-xl text-on-background mb-4">Pharmaco-vigilance Screener</h2>
          <p className="body-lg text-on-surface-variant max-w-2xl mx-auto">
            Input scientific literature titles and abstracts to identify Individual Case Safety Reports (ICSRs) describing adverse drug reactions in human patients.
          </p>
        </div>

        <div className="bg-surface-container-lowest p-6 rounded-xl border border-outline-variant shadow-sm relative">
          <label className="block label-md text-on-surface mb-2" htmlFor="drug-description">
            Drug Description Input
          </label>
          <div className="relative">
            <textarea
              id="drug-description"
              value={inputText}
              onChange={(e) => setInputText(e.target.value)}
              className="w-full bg-surface text-on-background code-md border border-outline-variant rounded-lg p-4 focus:ring-2 focus:ring-primary focus:border-transparent transition-all resize-none h-48"
              placeholder='Paste scientific article title and abstract here (e.g., "A 65-year-old male treated with Ibuprofen developed gastrointestinal bleeding...")'
            />
            <div className="absolute bottom-4 right-4 flex gap-2">
              <button className="text-on-surface-variant hover:text-primary transition-colors p-1.5 rounded-md hover:bg-surface-container">
                <Upload className="w-4 h-4" />
              </button>
              <button className="text-on-surface-variant hover:text-primary transition-colors p-1.5 rounded-md hover:bg-surface-container">
                <Share2 className="w-4 h-4" />
              </button>
            </div>
          </div>
          
          <div className="mt-6 flex justify-end">
            <button 
              onClick={handleAnalyze}
              disabled={isAnalyzing || !inputText.trim()}
              className="bg-primary text-on-primary px-6 py-2.5 rounded-lg label-md flex items-center gap-2 hover:bg-primary-container transition-all disabled:opacity-50"
            >
              {isAnalyzing ? (
                <>
                  <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                  Analyzing...
                </>
              ) : (
                <>
                  <Search className="w-4 h-4" />
                  Detect ICSRs
                </>
              )}
            </button>
          </div>
        </div>

        <div className="mt-12 text-center">
          <p className="label-md text-on-surface-variant mb-4 tracking-widest">Recent Protocols & Tags</p>
          <div className="flex flex-wrap justify-center gap-3">
            {[
              { icon: Activity, label: 'Adverse Reactions' },
              { icon: ShieldCheck, label: 'Patient Safety' },
              { icon: Tags, label: 'Drug Exposure' },
              { icon: Users, label: 'Human Reports' },
            ].map((tag) => (
              <span 
                key={tag.label}
                className="inline-flex items-center gap-2 px-4 py-2 bg-surface-container border border-outline-variant rounded-full label-md text-on-surface-variant cursor-pointer hover:bg-surface-container-high transition-colors"
              >
                <tag.icon className="w-4 h-4" />
                {tag.label}
              </span>
            ))}
          </div>
        </div>
      </div>
    </motion.main>
  );

  const ResultsScreen = () => (
    <motion.main 
      initial={{ opacity: 0, x: 20 }}
      animate={{ opacity: 1, x: 0 }}
      exit={{ opacity: 0, x: -20 }}
      className="flex-1 p-8 overflow-y-auto"
    >
      <div className="max-w-6xl mx-auto space-y-8">
        <div className="flex items-center justify-between">
          <div>
            <nav className="flex items-center gap-2 text-on-surface-variant body-sm mb-2">
              <button onClick={() => setShowResults(false)} className="hover:text-primary">Screener</button>
              <ChevronRight className="w-3 h-3" />
              <span className="text-on-surface font-medium">Analysis Report</span>
            </nav>
            <h2 className="headline-lg text-on-background">Screening Results</h2>
          </div>
          
          <div className="flex gap-3">
            <button className="bg-white border border-outline-variant text-on-surface px-4 py-2 rounded-lg label-md flex items-center gap-2 hover:bg-surface-container transition-all">
              <Database className="w-4 h-4" />
              Save to DB
            </button>
            <button className="bg-primary text-on-primary px-4 py-2 rounded-lg label-md flex items-center gap-2 hover:bg-primary-container transition-all">
              <FileText className="w-4 h-4" />
              Export ICSRs
            </button>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="bg-surface-container-lowest p-5 rounded-xl border border-outline-variant">
            <p className="label-md text-on-surface-variant mb-2">Total Tokens</p>
            <h3 className="headline-md">1,482</h3>
            <p className="body-sm text-secondary mt-1 flex items-center gap-1 font-medium">
              <ShieldCheck className="w-3 h-3" />
              Verified Structure
            </p>
          </div>
          <div className="bg-surface-container-lowest p-5 rounded-xl border border-outline-variant">
            <p className="label-md text-on-surface-variant mb-2">Detected Alerts</p>
            <h3 className="headline-md text-[#ba1a1a]">03 Case Reports</h3>
            <p className="body-sm text-[#ba1a1a] mt-1 font-medium">High Severity Found</p>
          </div>
          <div className="bg-surface-container-lowest p-5 rounded-xl border border-outline-variant">
            <p className="label-md text-on-surface-variant mb-2">Confidence Score</p>
            <h3 className="headline-md">98.4%</h3>
            <div className="w-full bg-surface-container h-1.5 rounded-full mt-3">
              <div className="bg-secondary h-full rounded-full" style={{ width: '98%' }} />
            </div>
          </div>
        </div>

        <div className="bg-surface-container-lowest border border-outline-variant rounded-xl overflow-hidden">
          <div className="px-6 py-4 border-b border-outline-variant bg-surface-container-low">
            <h3 className="label-md text-on-surface flex items-center gap-2">
              <ClipboardList className="w-4 h-4" />
              Individual Case Safety Reports
            </h3>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full text-left">
              <thead>
                <tr className="bg-surface border-b border-outline-variant">
                  <th className="px-6 py-3 label-md text-on-surface-variant">Event Type</th>
                  <th className="px-6 py-3 label-md text-on-surface-variant">Suspect Drug</th>
                  <th className="px-6 py-3 label-md text-on-surface-variant">Patient Profile</th>
                  <th className="px-6 py-3 label-md text-on-surface-variant">Severity</th>
                  <th className="px-6 py-3 label-md text-on-surface-variant">Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-outline-variant">
                {MOCK_RESULTS.map((row) => (
                  <tr key={row.id} className="hover:bg-surface-container-low transition-colors group">
                    <td className="px-6 py-4 body-md font-medium text-on-surface">{row.event}</td>
                    <td className="px-6 py-4 body-sm text-on-surface-variant font-mono">{row.drug}</td>
                    <td className="px-6 py-4 body-sm text-on-surface-variant">{row.patient}</td>
                    <td className="px-6 py-4">
                      <span className={`inline-flex px-2 py-1 rounded text-[10px] font-bold uppercase tracking-wider ${
                        row.severity === 'High' ? 'bg-[#ffdad6] text-[#93000a]' :
                        row.severity === 'Medium' ? 'bg-[#dae2ff] text-[#00419e]' :
                        'bg-secondary-container text-on-secondary-container'
                      }`}>
                        {row.severity}
                      </span>
                    </td>
                    <td className="px-6 py-4 text-right">
                      <button className="text-primary hover:underline label-md inline-flex items-center gap-1 group">
                        Review Case
                        <ArrowRight className="w-3 h-3 group-hover:translate-x-0.5 transition-transform" />
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        <div className="bg-surface-container-low p-6 rounded-xl border border-outline-variant border-dashed">
          <h4 className="label-md mb-2 text-on-surface">Original Input Preview</h4>
          <p className="body-md text-on-surface-variant code-md leading-relaxed line-clamp-3">
            {inputText}
          </p>
        </div>
      </div>
    </motion.main>
  );

  return (
    <div className="flex h-screen overflow-hidden bg-background">
      <Sidebar activePage={activePage} onPageChange={setActivePage} />
      
      <div className="flex-1 flex flex-col md:ml-64 h-full overflow-y-auto">
        <Header currentTab={currentTab} onTabChange={setCurrentTab} />
        
        <AnimatePresence mode="wait">
          {!showResults ? <LandingScreen key="landing" /> : <ResultsScreen key="results" />}
        </AnimatePresence>
      </div>
    </div>
  );
}
